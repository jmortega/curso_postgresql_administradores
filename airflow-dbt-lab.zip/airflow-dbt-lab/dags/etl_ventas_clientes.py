"""
DAG: etl_ventas_clientes
Descripción: Pipeline ETL completo que:
  1. Genera datos simulados de ventas y clientes (Extract)
  2. Los valida y transforma en Python (Transform)
  3. Los carga en PostgreSQL DWH en la capa raw (Load)
  4. Registra el resultado en pipeline_log

Programación: diaria a las 6:00 AM
"""

from __future__ import annotations

import logging
import random
from datetime import date, datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.postgres.operators.postgres import PostgresOperator

log = logging.getLogger(__name__)

# ── Datos de muestra ────────────────────────────────────────
PRODUCTOS = [
    ("Laptop Pro 15",   "Electrónica"),
    ("Teclado Mecánico","Periféricos"),
    ("Monitor 27\"",    "Electrónica"),
    ("Ratón Inalámbrico","Periféricos"),
    ("Auriculares BT",  "Audio"),
    ("Webcam HD",       "Periféricos"),
    ("SSD 1TB",         "Almacenamiento"),
    ("Hub USB-C",       "Accesorios"),
]

CLIENTES_SEMILLA = [
    (1,  "Ana García",    "ana@mail.com",    "Madrid",       "España",   "Premium"),
    (2,  "Luis Martínez", "luis@mail.com",   "Barcelona",    "España",   "Estandar"),
    (3,  "Sara López",    "sara@mail.com",   "México DF",    "México",   "Premium"),
    (4,  "Carlos Ruiz",   "carlos@mail.com", "Buenos Aires", "Argentina","Basico"),
    (5,  "Elena Sánchez", "elena@mail.com",  "Bogotá",       "Colombia", "Estandar"),
    (6,  "Pedro Jiménez", "pedro@mail.com",  "Lima",         "Perú",     "Basico"),
    (7,  "Laura Torres",  "laura@mail.com",  "Santiago",     "Chile",    "Premium"),
    (8,  "Miguel Flores", "miguel@mail.com", "Montevideo",   "Uruguay",  "Estandar"),
]

REGIONES = ["Norte", "Sur", "Este", "Oeste", "Centro"]


# ── Funciones ETL ───────────────────────────────────────────

def extraer_ventas(**context) -> list[dict]:
    """Extrae (simula) ventas de los últimos 7 días."""
    hoy = date.today()
    ventas = []
    n = random.randint(50, 120)

    for _ in range(n):
        producto, categoria = random.choice(PRODUCTOS)
        cliente = random.choice(CLIENTES_SEMILLA)
        ventas.append({
            "fecha":       str(hoy - timedelta(days=random.randint(0, 6))),
            "cliente_id":  cliente[0],
            "producto":    producto,
            "categoria":   categoria,
            "cantidad":    random.randint(1, 10),
            "precio_unit": round(random.uniform(15.0, 1200.0), 2),
            "region":      random.choice(REGIONES),
        })

    log.info("Extraídas %d ventas simuladas", len(ventas))
    context["ti"].xcom_push(key="ventas_raw", value=ventas)
    return ventas


def transformar_ventas(**context) -> list[dict]:
    """
    Valida y transforma las ventas:
    - Descarta registros con cantidad <= 0 o precio <= 0
    - Normaliza nombres de producto a Title Case
    """
    ventas: list[dict] = context["ti"].xcom_pull(
        task_ids="extraer_ventas", key="ventas_raw"
    )
    antes = len(ventas)
    ventas_ok = [
        {**v, "producto": v["producto"].title()}
        for v in ventas
        if v["cantidad"] > 0 and v["precio_unit"] > 0
    ]
    descartadas = antes - len(ventas_ok)
    log.info("Transformación: %d válidas, %d descartadas", len(ventas_ok), descartadas)
    context["ti"].xcom_push(key="ventas_transformadas", value=ventas_ok)
    return ventas_ok


def cargar_ventas(**context) -> int:
    """Carga las ventas en raw.ventas usando upsert por fecha+cliente+producto."""
    ventas: list[dict] = context["ti"].xcom_pull(
        task_ids="transformar_ventas", key="ventas_transformadas"
    )
    if not ventas:
        log.warning("Sin ventas para cargar")
        return 0

    hook = PostgresHook(postgres_conn_id="postgres_dwh")
    sql = """
        INSERT INTO raw.ventas
            (fecha, cliente_id, producto, categoria, cantidad, precio_unit, region)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    rows = [
        (v["fecha"], v["cliente_id"], v["producto"],
         v["categoria"], v["cantidad"], v["precio_unit"], v["region"])
        for v in ventas
    ]
    hook.insert_rows(table="raw.ventas", rows=rows, target_fields=[
        "fecha","cliente_id","producto","categoria","cantidad","precio_unit","region"
    ])
    log.info("Cargadas %d filas en raw.ventas", len(rows))
    context["ti"].xcom_push(key="filas_cargadas", value=len(rows))
    return len(rows)


def cargar_clientes(**context) -> None:
    """Carga o actualiza los clientes en raw.clientes (upsert por cliente_id)."""
    hook = PostgresHook(postgres_conn_id="postgres_dwh")
    sql = """
        INSERT INTO raw.clientes (cliente_id, nombre, email, ciudad, pais, segmento)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (cliente_id) DO UPDATE SET
            nombre   = EXCLUDED.nombre,
            email    = EXCLUDED.email,
            ciudad   = EXCLUDED.ciudad,
            pais     = EXCLUDED.pais,
            segmento = EXCLUDED.segmento
    """
    with hook.get_conn() as conn:
        with conn.cursor() as cur:
            cur.executemany(sql, CLIENTES_SEMILLA)
        conn.commit()
    log.info("Clientes cargados/actualizados: %d", len(CLIENTES_SEMILLA))


def registrar_log(**context) -> None:
    """Escribe el resultado del pipeline en raw.pipeline_log."""
    filas = context["ti"].xcom_pull(task_ids="cargar_ventas", key="filas_cargadas") or 0
    hook  = PostgresHook(postgres_conn_id="postgres_dwh")
    sql = """
        INSERT INTO raw.pipeline_log
            (pipeline, tarea, estado, filas_procesadas, inicio, fin, mensaje)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """
    ahora = datetime.utcnow()
    hook.run(sql, parameters=(
        "etl_ventas_clientes",
        "pipeline_completo",
        "SUCCESS",
        filas,
        context["data_interval_start"],
        ahora,
        f"Pipeline completado: {filas} filas de ventas cargadas",
    ))
    log.info("Log registrado en raw.pipeline_log")


# ── Definición del DAG ──────────────────────────────────────

default_args = {
    "owner":           "lab",
    "retries":         1,
    "retry_delay":     timedelta(minutes=2),
    "email_on_failure": False,
}

with DAG(
    dag_id="etl_ventas_clientes",
    description="Pipeline ETL: extracción, transformación y carga de ventas y clientes",
    schedule="0 6 * * *",          # Diario a las 6:00 AM
    start_date=datetime(2025, 1, 1),
    catchup=False,
    default_args=default_args,
    tags=["etl", "ventas", "postgres"],
) as dag:

    t_extraer = PythonOperator(
        task_id="extraer_ventas",
        python_callable=extraer_ventas,
    )

    t_transformar = PythonOperator(
        task_id="transformar_ventas",
        python_callable=transformar_ventas,
    )

    t_cargar_ventas = PythonOperator(
        task_id="cargar_ventas",
        python_callable=cargar_ventas,
    )

    t_cargar_clientes = PythonOperator(
        task_id="cargar_clientes",
        python_callable=cargar_clientes,
    )

    t_log = PythonOperator(
        task_id="registrar_log",
        python_callable=registrar_log,
    )

    # Flujo del pipeline
    t_extraer >> t_transformar >> t_cargar_ventas
    t_cargar_clientes >> t_log
    t_cargar_ventas  >> t_log
