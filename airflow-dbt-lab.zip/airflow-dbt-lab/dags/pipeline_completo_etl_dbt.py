"""
DAG: pipeline_completo_etl_dbt
Descripción: Pipeline end-to-end que encadena ETL Python + dbt via DockerOperator.

  generar_y_cargar_datos  →  dbt_staging  →  dbt_marts  →  dbt_test  →  reporte_final

dbt corre en contenedores efímeros (imagen dbt-lab:latest).
Programación: manual, ideal para demos y pruebas.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.docker.operators.docker import DockerOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.trigger_rule import TriggerRule
from docker.types import Mount

log = logging.getLogger(__name__)

# FIX: os.path.abspath(__file__) devuelve la ruta DENTRO del contenedor
# Airflow (/opt/airflow/dbt_project), no la del host. DockerOperator
# necesita la ruta del HOST. Se lee desde la variable de entorno
# DBT_PROJECT_HOST_PATH que el docker-compose inyecta con ${PWD}/dbt_project.
DBT_PROJECT_HOST_PATH = os.environ.get("DBT_PROJECT_HOST_PATH")
if not DBT_PROJECT_HOST_PATH:
    raise ValueError(
        "DBT_PROJECT_HOST_PATH no definida. Añade al servicio airflow-* en docker-compose.yml:\n"
        "  environment:\n"
        "    DBT_PROJECT_HOST_PATH: ${PWD}/dbt_project"
    )

DBT_ENV = {
    "DBT_POSTGRES_HOST":     "postgres-dwh",
    "DBT_POSTGRES_PORT":     "5432",
    "DBT_POSTGRES_USER":     "dwh_user",
    "DBT_POSTGRES_PASSWORD": "dwh_pass",
    "DBT_POSTGRES_DB":       "dwh",
    "DBT_POSTGRES_SCHEMA":   "public",
}

DBT_MOUNT = Mount(
    target="/dbt_project",
    source=DBT_PROJECT_HOST_PATH,
    type="bind",
    read_only=False,
)


def _dbt_operator(task_id: str, dbt_command: str, trigger_rule=None) -> DockerOperator:
    kwargs = {}
    if trigger_rule:
        kwargs["trigger_rule"] = trigger_rule
    return DockerOperator(
        task_id=task_id,
        image="dbt-lab:latest",
        command=f"{dbt_command} --profiles-dir /dbt_project --target prod",
        working_dir="/dbt_project",
        environment=DBT_ENV,
        mounts=[DBT_MOUNT],
        network_mode="etl_net",
        auto_remove="success",
        docker_url="unix:///var/run/docker.sock",
        mount_tmp_dir=False,
        **kwargs,
    )


def generar_y_cargar_datos(**context) -> int:
    """Genera ventas y clientes simulados y los carga en raw.*"""
    import random
    from datetime import date, timedelta

    PRODUCTOS = [
        ("Laptop Pro 15",    "Electrónica",    999.99),
        ("Teclado Mecánico", "Periféricos",     89.99),
        ("Monitor 27\"",     "Electrónica",    349.99),
        ("Ratón Inalámbrico","Periféricos",     29.99),
        ("Auriculares BT",   "Audio",          149.99),
        ("Webcam HD",        "Periféricos",     79.99),
        ("SSD 1TB",          "Almacenamiento", 109.99),
    ]
    REGIONES = ["Norte", "Sur", "Este", "Oeste", "Centro"]

    hook = PostgresHook(postgres_conn_id="postgres_dwh")
    hoy  = date.today()
    n    = random.randint(30, 80)

    rows = [
        (
            str(hoy - timedelta(days=random.randint(0, 6))),
            random.randint(1, 8),
            nombre,
            cat,
            random.randint(1, 5),
            round(precio * random.uniform(0.9, 1.1), 2),
            random.choice(REGIONES),
        )
        for nombre, cat, precio in [random.choice(PRODUCTOS) for _ in range(n)]
    ]
    hook.insert_rows(
        table="raw.ventas",
        rows=rows,
        target_fields=["fecha","cliente_id","producto","categoria",
                        "cantidad","precio_unit","region"],
    )

    clientes = [
        (1,"Ana García","ana@mail.com","Madrid","España","Premium"),
        (2,"Luis Martínez","luis@mail.com","Barcelona","España","Estandar"),
        (3,"Sara López","sara@mail.com","México DF","México","Premium"),
        (4,"Carlos Ruiz","carlos@mail.com","Buenos Aires","Argentina","Basico"),
        (5,"Elena Sánchez","elena@mail.com","Bogotá","Colombia","Estandar"),
    ]
    with hook.get_conn() as conn:
        with conn.cursor() as cur:
            cur.executemany("""
                INSERT INTO raw.clientes (cliente_id,nombre,email,ciudad,pais,segmento)
                VALUES (%s,%s,%s,%s,%s,%s)
                ON CONFLICT (cliente_id) DO UPDATE SET
                  nombre=EXCLUDED.nombre, segmento=EXCLUDED.segmento
            """, clientes)
        conn.commit()

    log.info("Cargadas %d ventas y %d clientes", n, len(clientes))
    context["ti"].xcom_push(key="filas_ventas", value=n)
    return n


def reporte_final(**context) -> None:
    """Lee marts y genera un reporte en los logs de Airflow."""
    hook  = PostgresHook(postgres_conn_id="postgres_dwh")
    total = hook.get_first(
        "SELECT COUNT(*), SUM(total_venta) FROM marts.ventas_enriquecidas"
    )
    cats  = hook.get_records("""
        SELECT categoria, num_ventas, ROUND(importe_total::numeric,2)
        FROM marts.resumen_por_categoria ORDER BY importe_total DESC
    """)

    log.info("=" * 52)
    log.info("📊 REPORTE FINAL DEL PIPELINE")
    log.info("=" * 52)
    log.info("Total filas marts.ventas_enriquecidas : %s",    total[0])
    log.info("Importe total acumulado               : %.2f €", float(total[1] or 0))
    log.info("-" * 52)
    for cat, n_v, imp in cats:
        log.info("  %-22s  %4d ventas  %10.2f €", cat, n_v, float(imp))
    log.info("=" * 52)


default_args = {
    "owner":            "lab",
    "retries":          0,
    "email_on_failure": False,
}

with DAG(
    dag_id="pipeline_completo_etl_dbt",
    description="Pipeline end-to-end: ETL Python → dbt (DockerOperator) → Reporte",
    schedule=None,
    start_date=datetime(2025, 1, 1),
    catchup=False,
    default_args=default_args,
    tags=["etl", "dbt", "docker", "demo"],
) as dag:

    t_cargar = PythonOperator(
        task_id="generar_y_cargar_datos",
        python_callable=generar_y_cargar_datos,
    )

    t_dbt_staging = _dbt_operator("dbt_staging", "run --select staging")
    t_dbt_marts   = _dbt_operator("dbt_marts",   "run --select marts")
    t_dbt_test    = _dbt_operator("dbt_test",    "test",
                                  trigger_rule=TriggerRule.ALL_SUCCESS)

    t_reporte = PythonOperator(
        task_id="reporte_final",
        python_callable=reporte_final,
    )

    t_cargar >> t_dbt_staging >> t_dbt_marts >> t_dbt_test >> t_reporte
