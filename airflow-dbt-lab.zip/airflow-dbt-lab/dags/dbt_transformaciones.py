"""
DAG: dbt_transformaciones
Descripción: Orquesta modelos dbt usando DockerOperator.

NOTA SOBRE LA RUTA DEL PROYECTO DBT:
  DockerOperator lanza contenedores en el Docker daemon del HOST, no dentro
  del contenedor Airflow. Por tanto, el source del Mount debe ser una ruta
  que exista en el HOST, no en el contenedor Airflow.

  os.path.abspath(__file__) devuelve la ruta DENTRO del contenedor Airflow
  (p.ej. /opt/airflow/dags/...), que no existe en el host → error 400.

  Solución: leer la ruta del host desde la variable de entorno
  DBT_PROJECT_HOST_PATH, que se inyecta en el contenedor Airflow desde
  docker-compose.yml con el valor correcto del host.

  En docker-compose.yml, bajo el servicio airflow-*, añadir:
    environment:
      DBT_PROJECT_HOST_PATH: /ruta/absoluta/en/el/host/dbt_project
  O con variable de entorno del shell:
      DBT_PROJECT_HOST_PATH: ${PWD}/dbt_project
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.docker.operators.docker import DockerOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from docker.types import Mount

log = logging.getLogger(__name__)

# ── Ruta del proyecto dbt en el HOST ─────────────────────────────────────────
# FIX: usar variable de entorno inyectada desde docker-compose,
# no os.path.abspath(__file__) que devuelve la ruta dentro del contenedor.
DBT_PROJECT_HOST_PATH = os.environ.get("DBT_PROJECT_HOST_PATH")

if not DBT_PROJECT_HOST_PATH:
    raise ValueError(
        "La variable de entorno DBT_PROJECT_HOST_PATH no está definida. "
        "Añádela al servicio airflow-* en docker-compose.yml:\n"
        "  environment:\n"
        "    DBT_PROJECT_HOST_PATH: ${PWD}/dbt_project"
    )

if not os.path.isabs(DBT_PROJECT_HOST_PATH):
    raise ValueError(
        f"DBT_PROJECT_HOST_PATH debe ser una ruta absoluta del host, "
        f"recibido: {DBT_PROJECT_HOST_PATH!r}"
    )

log.info("DBT_PROJECT_HOST_PATH = %s", DBT_PROJECT_HOST_PATH)

# ── Variables de entorno para el contenedor dbt ───────────────────────────────
DBT_ENV = {
    "DBT_POSTGRES_HOST":     "postgres-dwh",
    "DBT_POSTGRES_PORT":     "5432",
    "DBT_POSTGRES_USER":     "dwh_user",
    "DBT_POSTGRES_PASSWORD": "dwh_pass",
    "DBT_POSTGRES_DB":       "dwh",
    "DBT_POSTGRES_SCHEMA":   "public",
}

# Mount del proyecto dbt: source = ruta en el HOST
DBT_MOUNT = Mount(
    target="/dbt_project",
    source=DBT_PROJECT_HOST_PATH,
    type="bind",
    read_only=False,   # dbt escribe el directorio target/
)


def _dbt_operator(task_id: str, dbt_command: str) -> DockerOperator:
    return DockerOperator(
        task_id=task_id,
        image="dbt-lab:latest",
        command=f"{dbt_command} --profiles-dir /dbt_project --target prod",
        working_dir="/dbt_project",
        environment=DBT_ENV,
        mounts=[DBT_MOUNT],
        network_mode="etl_net",  # nombre real: prefijo_proyecto + nombre_red
        auto_remove="success",
        docker_url="unix:///var/run/docker.sock",
        mount_tmp_dir=False,
    )


def leer_resumen_marts(**context) -> dict:
    hook = PostgresHook(postgres_conn_id="postgres_dwh")

    # Verificar que las tablas existen antes de consultarlas.
    # Si dbt_run_marts falló parcialmente, esto da un error claro
    # en lugar de UndefinedTable genérico.
    tablas_requeridas = [
        ("marts", "ventas_enriquecidas"),
        ("marts", "resumen_por_categoria"),
    ]
    for schema, tabla in tablas_requeridas:
        existe = hook.get_first("""
            SELECT 1 FROM information_schema.tables
            WHERE table_schema = %s AND table_name = %s
        """, parameters=(schema, tabla))
        if not existe:
            raise ValueError(
                f"La tabla {schema}.{tabla} no existe en la BD. "
                f"Verifica que dbt_run_marts completó correctamente. "
                f"Ejecuta: SELECT * FROM information_schema.tables WHERE table_schema = '{schema}';"
            )

    resumen_ventas = hook.get_first("""
        SELECT
            COUNT(*)         AS total_filas,
            SUM(total_venta) AS importe_total,
            MIN(fecha_venta) AS fecha_min,
            MAX(fecha_venta) AS fecha_max
        FROM marts.ventas_enriquecidas
    """)

    resumen_categoria = hook.get_records("""
        SELECT categoria, num_ventas, importe_total
        FROM marts.resumen_por_categoria
        ORDER BY importe_total DESC
        LIMIT 5
    """)

    resumen = {
        "ventas_enriquecidas": {
            "total_filas":   resumen_ventas[0] if resumen_ventas else 0,
            "importe_total": float(resumen_ventas[1]) if resumen_ventas and resumen_ventas[1] else 0,
            "fecha_min":     str(resumen_ventas[2]) if resumen_ventas else None,
            "fecha_max":     str(resumen_ventas[3]) if resumen_ventas else None,
        },
        "top5_categorias": [
            {"categoria": r[0], "total_ventas": r[1], "importe": float(r[2])}
            for r in resumen_categoria
        ],
    }

    log.info("Resumen marts: %s", resumen)
    context["ti"].xcom_push(key="resumen_marts", value=resumen)
    return resumen


default_args = {
    "owner":            "lab",
    "retries":          1,
    "retry_delay":      timedelta(minutes=3),
    "email_on_failure": False,
}

with DAG(
    dag_id="dbt_transformaciones",
    description="Orquesta modelos dbt vía DockerOperator: staging → marts → tests",
    schedule="0 7 * * *",
    start_date=datetime(2025, 1, 1),
    catchup=False,
    default_args=default_args,
    tags=["dbt", "marts", "postgres", "docker"],
) as dag:

    t_dbt_debug = _dbt_operator("dbt_debug", "debug")
    t_dbt_run_staging = _dbt_operator("dbt_run_staging", "run --select staging")
    t_dbt_run_marts = _dbt_operator("dbt_run_marts", "run --select marts")
    t_dbt_test = _dbt_operator("dbt_test", "test")

    t_leer_resumen = PythonOperator(
        task_id="leer_resumen_marts",
        python_callable=leer_resumen_marts,
    )

    t_dbt_debug >> t_dbt_run_staging >> t_dbt_run_marts >> t_dbt_test >> t_leer_resumen
