-- =============================================================
-- Inicialización del Data Warehouse
-- Se ejecuta automáticamente al crear el contenedor postgres-dwh
-- =============================================================

-- Schema para datos crudos (capa raw / staging)
CREATE SCHEMA IF NOT EXISTS raw;

-- Schema para transformaciones dbt (capa marts)
CREATE SCHEMA IF NOT EXISTS marts;

-- =============================================================
-- Tabla fuente: ventas crudas (simulan un sistema transaccional)
-- =============================================================
CREATE TABLE IF NOT EXISTS raw.ventas (
    id            SERIAL PRIMARY KEY,
    fecha         DATE        NOT NULL,
    cliente_id    INTEGER     NOT NULL,
    producto      VARCHAR(100) NOT NULL,
    categoria     VARCHAR(50)  NOT NULL,
    cantidad      INTEGER     NOT NULL,
    precio_unit   NUMERIC(10,2) NOT NULL,
    region        VARCHAR(50)  NOT NULL,
    cargado_en    TIMESTAMP   DEFAULT now()
);

-- =============================================================
-- Tabla fuente: clientes crudos
-- =============================================================
CREATE TABLE IF NOT EXISTS raw.clientes (
    cliente_id    INTEGER PRIMARY KEY,
    nombre        VARCHAR(100) NOT NULL,
    email         VARCHAR(150),
    ciudad        VARCHAR(100),
    pais          VARCHAR(50),
    segmento      VARCHAR(50),   -- 'Premium', 'Estandar', 'Basico'
    cargado_en    TIMESTAMP   DEFAULT now()
);

-- =============================================================
-- Tabla de log de ejecuciones del pipeline (usada por Airflow)
-- =============================================================
CREATE TABLE IF NOT EXISTS raw.pipeline_log (
    id            SERIAL PRIMARY KEY,
    pipeline      VARCHAR(100) NOT NULL,
    tarea         VARCHAR(100) NOT NULL,
    estado        VARCHAR(20)  NOT NULL,  -- 'SUCCESS', 'FAILED'
    filas_procesadas INTEGER,
    inicio        TIMESTAMP,
    fin           TIMESTAMP,
    mensaje       TEXT
);

-- Permisos
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA raw   TO dwh_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA marts TO dwh_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA raw TO dwh_user;
GRANT USAGE ON SCHEMA raw, marts TO dwh_user;
