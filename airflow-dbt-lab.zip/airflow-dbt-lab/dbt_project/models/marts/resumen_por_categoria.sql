/*
  Modelo: resumen_por_categoria
  Capa:   marts
  Descripción: KPIs por categoría de producto y región.
*/
SELECT
    v.categoria,
    c.pais,
    count(*)                            AS num_ventas,
    round(sum(v.precio_unitario * v.cantidad)::numeric, 2) AS importe_total,
    round(avg(v.precio_unitario * v.cantidad)::numeric, 2) AS ticket_medio,
    count(DISTINCT v.cliente_id)        AS clientes_unicos
FROM {{ ref('stg_ventas') }} v
LEFT JOIN {{ ref('stg_clientes') }} c USING (cliente_id)
GROUP BY v.categoria, c.pais
ORDER BY importe_total DESC
