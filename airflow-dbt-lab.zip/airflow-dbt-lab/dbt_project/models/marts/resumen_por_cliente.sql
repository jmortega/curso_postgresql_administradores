/*
  Modelo: resumen_por_cliente
  Capa:   marts
  Descripción: Comportamiento RFM por cliente (Recency, Frequency, Monetary).
*/
SELECT
    v.cliente_id,
    c.nombre,
    c.segmento,
    c.pais,
    count(*)                                AS frecuencia,
    round(sum(v.precio_unitario * v.cantidad)::numeric, 2) AS valor_total,
    max(v.fecha_venta::DATE)                AS ultima_compra,
    now()::DATE - max(v.fecha_venta::DATE)  AS dias_desde_ultima_compra
FROM {{ ref('stg_ventas') }} v
LEFT JOIN {{ ref('stg_clientes') }} c USING (cliente_id)
GROUP BY v.cliente_id, c.nombre, c.segmento, c.pais
ORDER BY valor_total DESC
