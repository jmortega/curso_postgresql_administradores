/*
  Modelo: ventas_enriquecidas
  Capa:   marts
  Descripción: Une ventas con clientes para crear el modelo analítico principal.
               Añade campos derivados útiles para reporting.
  Materialización: table
*/

with ventas as (

    select * from {{ ref('stg_ventas') }}

),

clientes as (

    select * from {{ ref('stg_clientes') }}

),

enriquecido as (

    select
        -- Claves
        v.venta_id,
        v.cliente_id,

        -- Dimensión tiempo
        v.fecha_venta,
        extract(year  from v.fecha_venta)::int      as anio,
        extract(month from v.fecha_venta)::int      as mes,
        extract(week  from v.fecha_venta)::int      as semana,
        to_char(v.fecha_venta, 'YYYY-MM')           as anio_mes,
        trim(to_char(v.fecha_venta, 'Day'))         as dia_semana,

        -- Producto
        v.producto,
        v.categoria,
        v.region,

        -- Métricas de venta
        v.cantidad,
        v.precio_unitario,
        v.total_linea                               as total_venta,
        round(v.total_linea * 0.21, 2)              as iva_21,
        round(v.total_linea * 1.21, 2)              as total_con_iva,

        -- Dimensión cliente (enriquecida)
        c.nombre,
        c.email,
        c.ciudad,
        c.pais,
        c.segmento,
        c.fecha_registro,

        -- Clasificación del ticket
        case
            when v.total_linea >= 1000 then 'Alto'
            when v.total_linea >=  200 then 'Medio'
            else                            'Bajo'
        end                                         as ticket_categoria,

        -- Metadatos
        v.cargado_en

    from ventas v
    left join clientes c using (cliente_id)

)

select * from enriquecido
