/*
  Modelo: stg_ventas
  Capa:   staging
  Descripción: Limpia y estandariza las ventas crudas de raw.ventas.
  Materialización: view (definida en dbt_project.yml)
*/

with source as (

    select * from {{ source('raw', 'ventas') }}

),

limpieza as (

    select
        id                                         as venta_id,
        fecha::date                                as fecha_venta,
        cliente_id,
        upper(trim(producto))                      as producto,
        initcap(trim(categoria))                   as categoria,
        abs(cantidad)                              as cantidad,    -- garantizar positivo
        round(precio_unit::numeric, 2)             as precio_unitario,
        initcap(trim(region))                      as region,
        cantidad * precio_unit                     as total_linea, -- importe calculado
        cargado_en

    from source

    -- Filtrar registros inválidos
    where cantidad    > 0
      and precio_unit > 0
      and fecha       is not null
      and cliente_id  is not null

)

select * from limpieza
