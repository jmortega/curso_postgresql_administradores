/*
  Modelo: stg_clientes
  Capa:   staging
  Descripción: Limpia y estandariza los clientes crudos de raw.clientes.
*/
WITH fuente AS (
    SELECT * FROM {{ source('raw', 'clientes') }}
)
SELECT
    cliente_id,
    TRIM(UPPER(nombre))     AS nombre,
    TRIM(LOWER(email))      AS email,
    TRIM(pais)              AS pais,
    TRIM(ciudad)            AS ciudad,
    TRIM(segmento)          AS segmento,
    cargado_en::DATE        AS fecha_registro
FROM fuente
WHERE cliente_id IS NOT NULL
  AND email LIKE '%@%'
