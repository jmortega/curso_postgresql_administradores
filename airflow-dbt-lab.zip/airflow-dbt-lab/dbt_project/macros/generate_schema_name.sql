{#
  Macro: generate_schema_name
  Sobrescribe el comportamiento por defecto de dbt que concatena
  el schema del perfil con el custom_schema_name:
      por defecto: public_staging, public_marts
      con esta macro: staging, marts

  Regla:
    - Si el modelo tiene +schema definido → usar ese valor directamente
    - Si no tiene +schema → usar el schema del perfil (target.schema)
#}
{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- if custom_schema_name is none -%}
        {{ target.schema }}
    {%- else -%}
        {{ custom_schema_name | trim }}
    {%- endif -%}
{%- endmacro %}
