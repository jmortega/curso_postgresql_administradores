# 🚀 Laboratorio ETL: Apache Airflow + dbt + PostgreSQL

> **Stack completo con Docker Compose — dbt totalmente contenerizado.**  
> Airflow orquesta la ingesta en Python · dbt transforma en SQL dentro de su propio contenedor · PostgreSQL almacena todo.  
> **No es necesario instalar dbt ni ninguna dependencia en el host.**

---

## 🗂️ Estructura del proyecto

```
airflow-dbt-lab/
├── docker-compose.yml                    # Orquestación completa del stack
├── Dockerfile.dbt                        # Imagen dedicada para dbt
├── requirements.txt                      # Referencia de versiones
│
├── dags/
│   ├── etl_ventas_clientes.py            # DAG 1 — ETL Python (Extract→Transform→Load)
│   ├── dbt_transformaciones.py           # DAG 2 — Modelos dbt vía DockerOperator
│   └── pipeline_completo_etl_dbt.py     # DAG 3 — Pipeline end-to-end
│
├── dbt_project/
│   ├── dbt_project.yml                   # Configuración del proyecto dbt
│   ├── profiles.yml                      # Conexión a PostgreSQL (usa env vars)
│   └── models/
│       ├── staging/
│       │   ├── sources.yml               # Tablas fuente en raw.*
│       │   ├── stg_ventas.sql            # Vista: limpieza de ventas
│       │   └── stg_clientes.sql          # Vista: limpieza de clientes
│       └── marts/
│           ├── schema.yml                # Tests de calidad de datos
│           ├── ventas_enriquecidas.sql   # Tabla: ventas + cliente + derivados
│           ├── resumen_por_categoria.sql # Tabla: KPIs por categoría/región
│           └── resumen_por_cliente.sql   # Tabla: comportamiento RFM
│
└── scripts/
    └── init_dwh.sql                      # Inicialización del DWH (schemas + tablas)
```

---

## 🌐 Servicios del stack

| Servicio | Puerto | Descripción |
|---|---|---|
| **Airflow UI** | `8080` | Interfaz web (`admin` / `admin`) |
| **postgres-dwh** | `5433` | Data Warehouse (`dwh_user` / `dwh_pass`) |
| **dbt-runner** | — | Imagen `dbt-lab:latest`; sin puerto, invocado por Airflow |
| **postgres-meta** | interno | Metadatos de Airflow |

---

## 🏗️ Arquitectura

```
┌──────────────────────────────────────────────────────────────────┐
│                        DOCKER COMPOSE                            │
│                                                                  │
│  ┌─────────────────────┐    DockerOperator      ┌────────────┐  │
│  │   Apache Airflow     │ ──────────────────────▶│ dbt-runner │  │
│  │                      │  lanza contenedor      │ (efímero)  │  │
│  │  DAG 1 (Python ETL)  │  desde dbt-lab:latest  │            │  │
│  │  · extract           │                        │ dbt run    │  │
│  │  · transform         │◀── /var/run/docker.sock│ dbt test   │  │
│  │  · load → raw.*      │                        └─────┬──────┘  │
│  │                      │                              │         │
│  │  DAG 2 (dbt)         │                              │ SQL     │
│  │  DAG 3 (completo)    │                              ▼         │
│  └─────────────────────┘                    ┌──────────────────┐ │
│          │  PostgresHook                    │  PostgreSQL DWH  │ │
│          └─────────────────────────────────▶│                  │ │
│                                             │  schema: raw     │ │
│                                             │  schema: marts   │ │
│                                             │  schema: public  │ │
│                                             └──────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

### Cómo funciona `DockerOperator`

Airflow tiene acceso al socket de Docker del host (`/var/run/docker.sock`).
Cuando un DAG ejecuta un `DockerOperator`:

1. Airflow crea un contenedor nuevo desde la imagen `dbt-lab:latest`.
2. Le monta el directorio `./dbt_project` y le inyecta las variables de entorno de conexión.
3. Lo conecta a la red `etl_net` para que alcance `postgres-dwh` por nombre.
4. El contenedor ejecuta el comando dbt y termina.
5. Airflow recoge el código de salida (0 = éxito, otro = fallo) y lo refleja en la UI.

```
Airflow scheduler
      │
      │  docker run --rm \
      │    --network etl_net \
      │    -v ./dbt_project:/dbt_project \
      │    -e DBT_POSTGRES_HOST=postgres-dwh ... \
      │    dbt-lab:latest \
      │    run --select marts --profiles-dir /dbt_project --target prod
      ▼
  contenedor efímero (vive solo lo que dura el comando dbt)
```

---

## ⚡ Inicio rápido

### 1 — Prerequisitos

```bash
docker --version          # 24+
docker compose version    # 2.20+
```

### 2 — Preparar directorios y permisos

```bash
cd airflow-dbt-lab

# Airflow escribe logs con el UID del proceso interno
echo "AIRFLOW_UID=$(id -u)" > .env
```

### 3 — Construir la imagen dbt y levantar el stack

```bash
# Construye dbt-lab:latest y levanta todos los servicios
docker compose up --build airflow-init

# Una vez que airflow-init termina (exit 0), levantar el resto
docker compose up -d

# Verificar estado
docker compose ps
```

**Salida esperada:**

```
NAME                   STATUS            PORTS
postgres-meta          running (healthy)
postgres-dwh           running (healthy)  0.0.0.0:5433->5432/tcp
dbt-runner             running
airflow-webserver      running (healthy)  0.0.0.0:8080->8080/tcp
airflow-scheduler      running
```
interfaz airflow

http://localhost:8080/login/
user:admin
password:admin

### 4 — Registrar la conexión a PostgreSQL en Airflow

```bash
docker exec -it airflow-webserver airflow connections add postgres_dwh \
  --conn-type     postgres \
  --conn-host     postgres-dwh \
  --conn-login    dwh_user \
  --conn-password dwh_pass \
  --conn-schema   dwh \
  --conn-port     5432
```

O desde la UI: **Admin → Connections → +** con los mismos datos.

---

## Práctica 1 — DAG ETL con Python (`etl_ventas_clientes`)

### Qué hace

```
extraer_ventas → transformar_ventas → cargar_ventas ──┐
                                                       ▼
cargar_clientes ──────────────────────────────── registrar_log
```

Toda la lógica corre en `PythonOperator` dentro de Airflow.
Los datos pasan entre tareas mediante **XCom**.

### Ejecutar

```bash
docker exec -it airflow-scheduler \
  airflow dags trigger etl_ventas_clientes
```

### Verificar en PostgreSQL

```bash
psql -h localhost -p 5433 -U dwh_user -d dwh
password:dwh_pass
```

```sql
-- Últimas ventas cargadas
SELECT fecha, producto, categoria, cantidad, precio_unit
FROM raw.ventas
ORDER BY cargado_en DESC LIMIT 10;

-- Log del pipeline
SELECT pipeline, estado, filas_procesadas, fin
FROM raw.pipeline_log ORDER BY id DESC;
```

---

## Práctica 2 — Modelos dbt via DockerOperator (`dbt_transformaciones`)

### Qué hace

Cada tarea lanza un contenedor efímero desde `dbt-lab:latest`:

```
dbt_debug → dbt_run_staging → dbt_run_marts → dbt_test → leer_resumen_marts
  (contenedor)   (contenedor)   (contenedor)  (contenedor)  (PythonOperator)
```

### Ejecutar

```bash
docker exec -it airflow-scheduler \
  airflow dags trigger dbt_transformaciones
```

### Verificar que los contenedores se crean y destruyen

Mientras el DAG corre, en otra terminal:

```bash
# Ver los contenedores dbt efímeros en ejecución
watch docker ps --filter ancestor=dbt-lab:latest
```

### Verificar los marts generados

```sql
-- Ventas enriquecidas con datos del cliente
SELECT fecha_venta, nombre_cliente, segmento, producto,
       total_venta, ticket_categoria
FROM marts.ventas_enriquecidas
ORDER BY total_venta DESC LIMIT 10;

-- Resumen por categoría con % sobre el total
SELECT categoria, region, total_ventas,
       importe_total, ticket_medio, pct_sobre_total
FROM marts.resumen_por_categoria;

-- Clasificación RFM de clientes
SELECT nombre_cliente, num_compras, gasto_total, clasificacion_rfm
FROM marts.resumen_por_cliente ORDER BY gasto_total DESC;
```

### Ejecutar dbt manualmente (sin Airflow)

```bash
# Usar el servicio dbt-runner directamente
docker exec -it dbt-runner sh   # el contenedor está en reposo (tail -f /dev/null)

# Desde dentro:
dbt debug  --profiles-dir /dbt_project --target prod
dbt run    --profiles-dir /dbt_project --target prod --select staging
dbt run    --profiles-dir /dbt_project --target prod --select marts
dbt test   --profiles-dir /dbt_project --target prod

# O en una sola línea desde el host:
docker exec dbt-runner dbt run \
  --profiles-dir /dbt_project \
  --target prod \
  --select marts
```

---

## Práctica 3 — Pipeline end-to-end (`pipeline_completo_etl_dbt`)

### Qué hace

```
generar_y_cargar_datos → dbt_staging → dbt_marts → dbt_test → reporte_final
     (PythonOperator)    (Docker)       (Docker)    (Docker)  (PythonOperator)
```

### Ejecutar y ver el reporte

```bash
docker exec -it airflow-scheduler \
  airflow dags trigger pipeline_completo_etl_dbt

# buscar el run_id más reciente y leer ese log
docker exec airflow-scheduler \
  find /opt/airflow/logs/dag_id=pipeline_completo_etl_dbt \
       -name "*.log" -newer /opt/airflow/logs/.gitkeep \
  | sort | tail -5


# Ver el reporte en logs de la tarea final
# leer el fichero de log directamente a partir del run_id obtenido del comando anterior
docker exec airflow-scheduler 
  cat /opt/airflow/logs/dag_id=pipeline_completo_etl_dbt/run_id=manual__2026-06-27T22:47:54+00:00/task_id=reporte_final/attempt=1.log
```

**Reporte esperado:**

```
====================================================
📊 REPORTE FINAL DEL PIPELINE
====================================================
Total filas marts.ventas_enriquecidas : 342
Importe total acumulado               : 48732.50 €
----------------------------------------------------
  Electrónica             85 ventas    22150.75 €
  Periféricos             97 ventas    11230.40 €
  Audio                   60 ventas     9870.20 €
====================================================
```

---

## 🔍 Consultas de verificación rápida

```sql
-- Volumen de datos por capa
SELECT 'raw.ventas'                  AS tabla, COUNT(*) FROM raw.ventas
UNION ALL
SELECT 'raw.clientes',                          COUNT(*) FROM raw.clientes
UNION ALL
SELECT 'marts.ventas_enriquecidas',             COUNT(*) FROM marts.ventas_enriquecidas
UNION ALL
SELECT 'marts.resumen_por_categoria',           COUNT(*) FROM marts.resumen_por_categoria;

-- Últimas ejecuciones del pipeline ETL
SELECT pipeline, estado, filas_procesadas,
       EXTRACT(epoch FROM (fin - inicio)) AS segundos
FROM raw.pipeline_log ORDER BY id DESC LIMIT 5;

-- Objetos creados por dbt en cada schema
SELECT schemaname, tablename, 'table' AS tipo
FROM pg_tables WHERE schemaname IN ('public','marts')
UNION ALL
SELECT schemaname, viewname, 'view'
FROM pg_views  WHERE schemaname IN ('public','marts')
ORDER BY schemaname, tipo, tablename;
```

---

## 🛠️ Comandos útiles

```bash
# Reconstruir solo la imagen dbt (tras cambios en Dockerfile.dbt o requirements)
docker compose build dbt-runner

# Ver logs del scheduler (donde aparecen errores de DockerOperator)
docker compose logs -f airflow-scheduler

# Listar contenedores dbt que quedaron sin limpiar (si auto_remove falló)
docker ps -a --filter ancestor=dbt-lab:latest

# Limpiarlos manualmente
docker rm $(docker ps -aq --filter ancestor=dbt-lab:latest)

# Conectar al DWH
psql -h localhost -p 5433 -U dwh_user -d dwh

# Detener el stack (conserva datos en volúmenes)
docker compose down

# Detener y borrar todo, incluyendo volúmenes
docker compose down -v
```

---

## ⚠️ Resolución de problemas frecuentes

### `DockerOperator` falla con "Permission denied" al socket

```bash
# El usuario que corre el scheduler necesita acceso al socket
sudo usermod -aG docker $(whoami) && newgrp docker

# Verificar que el socket es accesible
docker exec airflow-scheduler docker ps
```

### `DockerOperator` no encuentra la imagen `dbt-lab:latest`

```bash
# Reconstruir la imagen
docker compose build dbt-runner

# Verificar que existe
docker images dbt-lab
```

### dbt no alcanza `postgres-dwh` desde el contenedor efímero

```bash
# Verificar que la red etl_net existe
docker network ls | grep etl_net

# Inspeccionar qué contenedores están en la red
docker network inspect etl_net
```

El `DockerOperator` debe tener `network_mode="etl_net"` (ya configurado en los DAGs).
En Docker Desktop (Mac/Windows) puede ser necesario usar `network_mode="host"` o el nombre completo de la red con el prefijo del proyecto: `airflow-dbt-lab_etl_net`.

### Airflow no encuentra los DAGs

```bash
# Verificar montaje del volumen
docker exec airflow-scheduler ls /opt/airflow/dags/

# Forzar re-scan
docker exec airflow-scheduler airflow dags reserialize
```

---

## 📚 Referencias

- [Apache Airflow — DockerOperator](https://airflow.apache.org/docs/apache-airflow-providers-docker/)
- [dbt-postgres — Documentación](https://docs.getdbt.com/docs/core/connect-data-platform/postgres-setup)
- [dbt best practices — Capas staging/marts](https://docs.getdbt.com/guides/best-practices)
- [PostgresHook — Airflow Provider](https://airflow.apache.org/docs/apache-airflow-providers-postgres/)
